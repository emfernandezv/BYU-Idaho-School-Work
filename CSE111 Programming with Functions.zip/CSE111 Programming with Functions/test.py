students = {
    "10-450-1203" : "Jorge Soares",
    "75-421-2310" : "Abdul Ali",
    "07-103-5621" : "Michelle Davis"
}

name = students["75-421-2310"]

print(students)
print(name)