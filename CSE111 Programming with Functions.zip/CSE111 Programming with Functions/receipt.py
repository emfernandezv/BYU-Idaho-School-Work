numbers = [23, -7, 8.5, 16, 30]
numbers.index(5) = position
print(position)